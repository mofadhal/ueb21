#ifndef LIBRARY_TWO_NiNCLUDED
#define LIBRARY_TWO_INCLUDED

float getZeitZero();
float getBeschleunigung();
float getGeschwindigkeitZero();

float wggb ();
float wgbgb ();
float ggbgg ();

#endif
