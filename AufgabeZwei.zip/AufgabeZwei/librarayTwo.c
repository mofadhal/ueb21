#include "librarayTwo.h"
#include "librarayOne.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

//Mit: v := Geschwindigkeit, a := Beschleunigung, p := Impuls, s := Weg, t := Zeit, m = Masse
//i Weg einer gleichförmigen geradlinigen Bewegung: s = v · (t − t 0 )
//ii Weg einer gleichmäßig beschleunigten geradlinigen Bewegung: s = 2a 0
// iii Geschwindigkeit einer gleichmäßig beschleunigten geradlinigen Bewegung: v = a · (t − t 0 ) + v 0

float getZeitZero(){
float x;
printf("Geben Sie bitte die AnfangsZeit\n");

if(scanf("%f", &x) != 1){
zahl();
while((getchar())!='\n');
x = getZeitZero();


}
 
 return x;
}
///////////////////
float getBeschleunigung(){
float x;
printf("Geben Sie bitte die Beschleunigung\n");

if(scanf("%f", &x) != 1 || x== 0){
printf("\n\n	*** Es soll Zahl sein und ungleich null (0) ***	\n\n\n");
while((getchar())!='\n');
x = getBeschleunigung();


}
 
 return x;
}
//////////////
float getGeschwindigkeitZero(){
float x;
printf("Geben Sie bitte der GeschwindigkeitsAnfang\n");

if(scanf("%f", &x) != 1 ){
zahl();
while((getchar())!='\n');
x = getGeschwindigkeitZero();


}
 
 return x;
}
////////////////


float wggb (){float v = getGeschwindigkeit(); float t =  getZeit(); float tz = getZeitZero() ; return (v * (t - tz));}

float wgbgb () {float a = getBeschleunigung() ; float v = getGeschwindigkeit(); float vz = getGeschwindigkeitZero(); return ((v * v)-(vz * vz) / 2*a);}

float ggbgg (){float a = getBeschleunigung() ; float t = getZeit() ; float tz = getZeitZero(); float vz = getGeschwindigkeitZero() ; return ((a*(t - tz)) + vz); }
