#include <stdio.h>
#include "librarayOne.h"
#include "librarayTwo.h"
#include <stdlib.h>
//#include <assert.h>


int getOp(){
int x;


if(scanf("%d", &x) != 1 || x>6 || x<0){
printf("\n\n	*** Die Eingabe soll ein Zahl zwischen 0 und 6 sein ***	\n\n\n");
Opss();

while((getchar())!='\n');

x = getOp();

}
 
 return x;
}

void Opss(){
printf("	Geben Sie bitte an, was berechnet werden muss : 	\n 0) Exit\n 1) Geschwindigkeit\n 2) Beschleunigung\n 3) Impuls\n 4) Weg einer gleichförmigen geradlinigen Bewegung\n 5) Weg einer gleichmäßig beschleunigten geradlinigen Bewegung\n 6) Geschwindigkeit einer gleichmäßig beschleunigten geradlinigen Bewegung\n");
}


int main(int argc, char** argv){
  int c = 0; 
  int x = 1; 
  while (x != 0){
  Opss();
  

c = getOp();
//printf("Die Eingabe soll ein Zahl zwischen 1 und 6 sein\n");
//while((getchar())!='\n');
// printf("%d\n", c);

switch(c){
float Masse , Zeit , Geschwindigkeit ,  zz , a ,vz , tz , Result;
case 0: 
	printf("	ByeBye	\n");
	exit(0);
case 1 : 
Result = geschwindigkeit();
printf("\n\n	***	Geschwindigkeit betraegt : %f	***	 \n\n\n", Result);
break;


case 2:
//float beschleunigung (float geschwindigkeit, float zeit );
Result = beschleunigung();
printf("\n\n	***	Beschleunigung betraegt : %f	***	 \n\n\n",Result);
break;

case 3:
// float impuls (float geschwindigkeit , float masse );
Result = impuls();
printf("\n\n	***	Impuls betraegt : %f	***	 \n\n\n",Result);
break;



case 4:
// float wggb (float v , float z , float zz);

Result = wggb();
 
printf("\n\n	***	WggB betraegt : %f	***	 \n\n\n", Result);
break;

case 5: 
// float wgbgb (float a , float v , float vz);
Result = wgbgb();
 
printf("\n\n	***	WgbgB betraegt : %f	***	 \n\n\n", Result);
break;

case 6: 
// float ggbgg (float a , float t , float tz , float vz);
Result = ggbgg ();
 
printf("\n\n	***	GgbgB betraegt : %f	***	 \n\n\n", Result);
break;

default : 
break;
		
}
  
  } 
  
  
  
  return 0;
}
