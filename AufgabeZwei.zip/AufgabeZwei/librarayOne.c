#include "librarayOne.h"
#include <stdio.h>
#include <stdlib.h>

void zahl(){
printf("\n\n	*** Die Eingabe soll ein Zahl sein ***	\n\n\n");
}


float getMasse(){
float x;
printf("Geben Sie bitte die Masse\n");

if(scanf("%f", &x) != 1){
zahl();
while((getchar())!='\n');
x = getMasse();

}
 
 return x;
}
////////////////////////
float getZeit(){
float x;
printf("Geben Sie bitte die Zeit\n");

if(scanf("%f", &x) != 1){
zahl();

while((getchar())!='\n');
x = getZeit();


}
 
 return x;
}
///////////////////////////////

float getGeschwindigkeit(){

float x;
printf("Geben Sie bitte die Geschwindigkeit\n");

if(scanf("%f", &x) != 1){
zahl();
while((getchar())!='\n');
x = getGeschwindigkeit();

}
 
 return x;


}
///////////////////

float geschwindigkeit(){float masse = getMasse() ; float zeit = getZeit(); return masse/zeit;}

float beschleunigung(){float geschwindigkeit = getGeschwindigkeit() ; float zeit = getZeit() ;return geschwindigkeit/zeit;}

float impuls(){float geschwindigkeit = getGeschwindigkeit() ;float masse = getMasse();return geschwindigkeit * masse ; } 


