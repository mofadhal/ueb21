#ifndef LIBRARY_ONE_NiNCLUDED
#define LIBRARY_ONE_INCLUDED

float getMasse();
float getZeit();
float getGeschwindigkeit();
float geschwindigkeit ();
float beschleunigung ( );
float impuls ( );
void zahl();
#endif
